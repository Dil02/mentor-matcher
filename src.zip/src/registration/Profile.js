export default function Profile(){

    function handleChange(){

    }

    function handleClick(){
        
    }

    return(
        <div className="fields">
            <input type="file" onchange={handleChange} />
        </div>



    );
}