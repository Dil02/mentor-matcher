import './Selection.css';
import {useState, useEffect} from "react";
import profilePic from './profilePic.jpg';
import {auth} from ".././firebase/firebase-config";
import ProgressBar from ".././ProgressBar/ProgressBar";
import {db} from ".././firebase/firebase-config"; 
import {getDocs, collection} from "firebase/firestore";

function MentorBox(i, name, job, email, phone, description) {
    if (name == "NULL") {
      return(null)
    }
    var color = "#7a3fc2"
    if (i == 2) { color = '#42b0cc'} 
    return(
        <div class="btn w-100" id={"btn-" + i}>
            <a href="" >
            <img  src={profilePic} className="rounded-circle" height="200"/>
            <div class="text-center">
                <h2> {name} </h2>
                <h4> {job} </h4>
                <br/>
                <p> <strong>Email: </strong></p>
                <p class="p-0"> {email} </p>
                <br/>
                <p> <strong> Phone: </strong></p>
                <p>{phone}</p>
                <br/>
                <p> <strong>Description: </strong></p>
                <p>{description}</p>
            </div>
            <div id="bar">
                <ProgressBar bgcolor={color} completed="60"/>
            </div>
          </a>
        </div>
    )
}

function showMentors(infoArray) {
  return(
    <div  class="btn-group d-flex" role="group">
      {MentorBox(1, infoArray[0][0], infoArray[0][1], infoArray[0][2], infoArray[0][3], infoArray[0][4])}
      {MentorBox(2, infoArray[1][0], infoArray[1][1], infoArray[1][2], infoArray[1][3], infoArray[1][4])}
      {MentorBox(1, infoArray[2][0], infoArray[2][1], infoArray[2][2], infoArray[2][3], infoArray[2][4])}
      {MentorBox(2, infoArray[3][0], infoArray[3][1], infoArray[3][2], infoArray[3][3], infoArray[3][4])}
      {MentorBox(1, infoArray[4][0], infoArray[4][1], infoArray[4][2], infoArray[4][3], infoArray[4][4])} 
    </div>
  )
}
function Selection() {
  const [displayMentors, setDisplayMentors] = useState([]);
  const mentorCol = collection(db, "Mentors");
  
  useEffect(() => {
    const getMentors = async () => {
        const data = await getDocs(mentorCol);
        setDisplayMentors(data.docs.map((doc) => ({...doc.data(), id: doc.id})));
        //In the above line we are looping through the documents in the collection 
        // and setting the users array to be equal to an array of the document data and id for each document.
    }

    getMentors();
  }, []);


  var infoArray = [["none", "none", "none", "none", "none"], 
                  ["none", "none", "none", "none", "none"], 
                  ["none", "none", "none", "none", "none"], 
                  ["none", "none", "none", "none", "none"], 
                  ["none", "none", "none", "none", "none"]]
  for (let i = 0; i < 5; i++) {
    if (displayMentors.length - 1 < i) {
      infoArray[i][0] = "NULL";
      infoArray[i][1] = "NULL";
      infoArray[i][2] = "NULL";
      infoArray[i][3] = "NULL";
      infoArray[i][4] = "NULL";
    } else {
      infoArray[i][0] = displayMentors[i].firstName + " " + displayMentors[i].surname;
      infoArray[i][1] = displayMentors[i].occupation;
      infoArray[i][2] = displayMentors[i].emailAddress;
      infoArray[i][3] = displayMentors[i].phone;
      infoArray[i][4] = displayMentors[i].description;
    }
    
  }


  return (
    <div class="selection">

        <div class="text-center p-4">
        {displayMentors.length == 0 ? <h2>Unfortunately you could not be matches with any mentors at this time</h2> : <h1>We have matched you with the following mentors. Please select one from below:</h1>}
        </div>
          {displayMentors.length == 0 ? <h2></h2> : showMentors(infoArray)}
    </div>
    
    
  );
}

export default Selection;
