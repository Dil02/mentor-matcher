import React from 'react'

function Pairings() {
    const mentorNumber = 5;
  return (
    <div>Pairings 
{/*     
    {for(var i = 0; i < mentorNumber; i++){

    }} */}

    </div>
  )
}

export default Pairings