import './AdminHome.css';

function AdminHome() {
  return (
    <div>
        <h2> HELLO </h2>
    </div>
  );
}

export default AdminHome;
