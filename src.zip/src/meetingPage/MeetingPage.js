import './MeetingPage.css';

function MeetingPage() {
    return (
        <div>
            <form>
                <h2> HI </h2> 
            </form>
        </div>
    );
}

export default MeetingPage;