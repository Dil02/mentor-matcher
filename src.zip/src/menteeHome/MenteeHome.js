import './menteeHome.css';

import {firestore} from  "../firebase/firebase-config";
import {collection, getDocs, addDoc, updateDoc, doc, deleteDoc, setDoc, Firestore,query, where, onSnapshot, getFirestore} from "@firebase/firestore";
import {useAuth} from "../firebase/firebase-config";
import { useEffect, useState } from "react";
import { getAuth,} from "firebase/auth";

function MenteeHome() {

    const currentUser = useAuth();
    const auth = getAuth();
    const userAuth = auth.currentUser;
    const emailAddr = userAuth.email;


    const [photoURL, setPhotoURL] = useState("https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png");

    const [users, setUsers] = useState([]);
    const usersCollectionRef = collection(firestore, "Mentees");
    const ref = collection(firestore, "Mentees");

    const db = getFirestore();
    const colRef = (collection(db, "Mentees"));

    const newArray=[]

    const tempFunction = async() =>{

        const q=query(colRef,where("emailAddress","==", emailAddr));
    
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
          console.log(doc.id, " => ", doc.data());
          newArray.push(doc.data());
        }); console.log(newArray); setUsers(newArray)
      
    }
  
    useEffect(() => {
        const getUsers = async (currentUser) => {
          tempFunction(currentUser);
        };
  
        getUsers();
      }, []);

    useEffect(() => {
        if (currentUser?.photoURL) {
          setPhotoURL(currentUser.photoURL);
        }
      }, [currentUser])

  return (

    <div>
{users.map((user) => {
        return(
          <div>
          {console.log(currentUser?.email)}


          <div>
            
            <div class="box1"> 
            <img src ={photoURL} width="200" height="200" class="center"/>
                    <h2> Welcome </h2>
                    <h2>{user.firstName} {user.surname}</h2>
                    <div class="center2">
                        <button class="button1"> View Profile </button>
                        <button class="button1"> Edit Profile </button>
                    </div>
            </div>
            <div class="box2">
                <table>
                    <tr>
                        <th>Mentor </th>
                    </tr>
                    <tr>
                        <td> John Smith </td>
                    </tr>	
                    <tr>
                        <td> Last Seen: 10am </td>
                    </tr>
                    <tr>
                        <button class="button2"> Message Mentor </button>
                    </tr>
                </table>
            </div>
            
            <div class="box3">
            <table>
                    <tr>
                        <th>Meetings</th>
                    </tr>
                    <tr>
                        <td> John Smith: 11am <button class="button2"> Join Meeting </button> </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>

);
})}

    </div>


    
    
  );
}

export default MenteeHome;
