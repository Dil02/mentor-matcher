import {useState, useEffect} from "react";
import {auth} from ".././firebase/firebase-config";
import {db} from ".././firebase/firebase-config"; 
import {getDoc, getDocs, collection, setDoc, doc, updateDoc} from "firebase/firestore";

function MenteeSelection() {
    return (
        <div class="bg-info">
            HOI
        </div>
    );
}

export default MenteeSelection;